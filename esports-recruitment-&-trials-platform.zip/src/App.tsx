/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { User, LogOut, ShieldAlert, Wifi, Download } from "lucide-react";
import HomeView from "./components/HomeView";
import RegisterView from "./components/RegisterView";
import GameCanvas from "./components/GameCanvas";
import { User as UserType } from "./types";

export default function App() {
  const [user, setUser] = useState<UserType | null>(null);
  const [currentView, setCurrentView] = useState<"login" | "register" | "game">("login");
  const [downloadDropdownOpen, setDownloadDropdownOpen] = useState(false);

  const handleLoginSuccess = (loggedInUser: UserType) => {
    setUser(loggedInUser);
    setCurrentView("game");
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentView("login");
  };

  const handleUpdateHighScore = (newHighScore: number) => {
    if (user) {
      setUser({ ...user, highScore: newHighScore });
    }
  };

  return (
    <div className="min-h-screen text-gray-100 bg-[#080c14] relative flex flex-col justify-between selection:bg-cyan-500 selection:text-black">
      {/* Background Neon Gradients */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-purple-600/10 rounded-full blur-[120px]" />
        <div className="absolute top-1/2 left-1/3 w-[500px] h-[500px] bg-cyan-500/5 rounded-full blur-[150px]" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-purple-500/10 rounded-full blur-[120px]" />
      </div>

      {/* Dynamic Header */}
      <header className="w-full max-w-7xl mx-auto px-6 py-5 flex justify-between items-center border-b border-gray-800/60 relative z-10 bg-[#080c14]/80 backdrop-blur-md">
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => user ? setCurrentView("game") : setCurrentView("login")}>
          <div className="w-9 h-9 rounded bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/10">
            <span className="font-mono font-black text-lg text-white">A</span>
          </div>
          <div>
            <h1 className="font-mono text-base font-extrabold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">TEAM APEX</h1>
            <p className="text-[9px] text-cyan-400/80 uppercase tracking-widest font-mono font-semibold">Esports Recruitment</p>
          </div>
        </div>

        {/* User Session Info / Action Bar */}
        <div className="flex items-center space-x-6 font-mono text-xs">
          
          {/* Download PHP/XAMPP Code Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setDownloadDropdownOpen(!downloadDropdownOpen)}
              className="flex items-center space-x-1.5 bg-gray-950/60 border border-gray-800 hover:border-cyan-500/50 text-cyan-400 px-3 py-1.5 rounded-lg transition-all text-[11px] font-bold tracking-wider cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>PHP CODE ASSETS</span>
            </button>
            
            {downloadDropdownOpen && (
              <div className="absolute right-0 mt-2 w-72 bg-gray-950 border border-gray-800 rounded-xl shadow-2xl p-4 z-50 text-xs space-y-3">
                <p className="text-gray-400 font-sans leading-relaxed">
                  The complete PHP/XAMPP version files are generated inside the workspace directory <code className="text-cyan-400 bg-cyan-950/20 px-1 py-0.5 rounded">/php-xampp/</code>.
                </p>
                <div className="border-t border-gray-800 pt-2 space-y-1.5">
                  <div className="text-[10px] text-purple-400 font-semibold uppercase">FILES GENERATED:</div>
                  <ul className="list-disc pl-4 space-y-1 text-gray-500 text-[10px]">
                    <li>esports_db.sql</li>
                    <li>db_connect.php</li>
                    <li>index.php</li>
                    <li>register.php</li>
                    <li>game.php</li>
                    <li>update_score.php</li>
                    <li>logout.php</li>
                  </ul>
                </div>
                <p className="text-[10px] text-gray-400 font-sans">
                  Copy them straight to your <code className="text-purple-400">htdocs</code> folder!
                </p>
              </div>
            )}
          </div>

          {user ? (
            <div className="flex items-center space-x-4">
              <div className="hidden sm:block text-right border-r border-gray-800/80 pr-4">
                <div className="text-[9px] text-gray-500 uppercase tracking-widest">Recruit Handle</div>
                <div className="text-cyan-400 font-bold font-mono">{user.username}</div>
              </div>

              <button
                onClick={handleLogout}
                className="flex items-center space-x-1.5 bg-red-950/30 hover:bg-red-900/40 text-red-400 border border-red-500/30 px-3 py-1.5 rounded-lg transition-all text-[11px] font-bold cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">DISCONNECT SESSION</span>
              </button>
            </div>
          ) : (
            <div className="hidden md:flex items-center space-x-2 text-gray-500">
              <Wifi className="w-3.5 h-3.5 text-green-400 animate-pulse" />
              <span>SYS_STATUS: </span>
              <span className="text-green-400 font-bold uppercase tracking-widest">TRIALS_OPEN</span>
            </div>
          )}
        </div>
      </header>

      {/* Main View Router Container */}
      <main className="flex-grow flex items-center justify-center px-4 py-8 relative z-10 w-full max-w-7xl mx-auto">
        <AnimatePresence mode="wait">
          {currentView === "login" && (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="w-full"
            >
              <HomeView
                onLoginSuccess={handleLoginSuccess}
                onNavigateToRegister={() => setCurrentView("register")}
              />
            </motion.div>
          )}

          {currentView === "register" && (
            <motion.div
              key="register"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="w-full"
            >
              <RegisterView onBackToLogin={() => setCurrentView("login")} />
            </motion.div>
          )}

          {currentView === "game" && user && (
            <motion.div
              key="game"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3, ease: "easeOut" }}
              className="w-full"
            >
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-gray-950/40 border border-gray-800/80 p-5 rounded-2xl">
                  <div>
                    <h2 className="font-mono text-lg font-bold text-white tracking-wide uppercase">
                      AR HAND-TRACKING ARENA
                    </h2>
                    <p className="text-xs text-gray-400 mt-1">
                      Recruitment trials are fully operational. Match hand pointer coordinates cleanly to score points.
                    </p>
                  </div>
                  <div className="mt-3 sm:mt-0 font-mono text-[11px] bg-cyan-950/20 border border-cyan-500/20 text-cyan-400 px-3.5 py-1.5 rounded-lg flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
                    <span>TRAINEE MONITORED SECURELY</span>
                  </div>
                </div>

                <GameCanvas user={user} onUpdateHighScore={handleUpdateHighScore} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="w-full max-w-7xl mx-auto px-6 py-5 border-t border-gray-800/60 flex flex-col md:flex-row justify-between items-center text-xs text-gray-500 font-mono space-y-2 md:space-y-0 bg-[#080c14]/80">
        <div>
          &copy; {new Date().getFullYear()} TEAM APEX ESPORTS. TRIAL PROTOCOLS ACTIVE.
        </div>
        <div className="flex items-center space-x-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-purple-400" />
          <span>XAMPP (PHP/MySQL) EXPORT DIRECTORY READY AT <code className="text-cyan-400">/php-xampp/</code></span>
        </div>
      </footer>
    </div>
  );
}
