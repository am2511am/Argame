/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import { Camera as CameraIcon, HelpCircle, Shield, Sparkles, Volume2, VolumeX, Zap } from "lucide-react";
import { GameState, User } from "../types";

interface GameCanvasProps {
  user: User;
  onUpdateHighScore: (score: number) => void;
}

export default function GameCanvas({ user, onUpdateHighScore }: GameCanvasProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Game states
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(user.highScore);
  const [trackingStatus, setTrackingStatus] = useState("Initializing systems...");
  const [fallbackMode, setFallbackMode] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [cameraActive, setCameraActive] = useState(false);

  // Mutable game refs (to prevent state delays in continuous high-performance requestAnimationFrame loop)
  const scoreRef = useRef(0);
  const starPosRef = useRef({ x: 320, y: 240, size: 25 });
  const pointerRef = useRef({ x: 0, y: 0, active: false });
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Play a beautiful synthesized synth beep when hitting a star using Web Audio API
  const playHitSound = () => {
    if (!soundEnabled) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") {
        ctx.resume();
      }

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      // Arpeggiated esports chime: starts at 520Hz (C5), slides quickly to 1040Hz (C6)
      osc.frequency.setValueAtTime(520, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1040, ctx.currentTime + 0.15);

      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch (e) {
      console.warn("AudioContext block", e);
    }
  };

  // Generate a random star coordinate, keeping it safely away from boundaries
  const spawnStar = () => {
    if (canvasRef.current) {
      const canvas = canvasRef.current;
      const x = Math.floor(Math.random() * (canvas.width - 120)) + 60;
      const y = Math.floor(Math.random() * (canvas.height - 120)) + 60;
      starPosRef.current = { x, y, size: 22 };
    }
  };

  // Asynchronously transmit high score to our Express API
  const saveScoreToDatabase = async (currentScore: number) => {
    try {
      const res = await fetch("/api/update_score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: user.username, score: currentScore })
      });
      if (res.ok) {
        const data = await res.json();
        if (data.success) {
          if (data.newHighScore) {
            setHighScore(data.highScore);
            onUpdateHighScore(data.highScore);
          }
        }
      }
    } catch (e) {
      console.error("Failed to sync score with database", e);
    }
  };

  // Canvas drawing routine for golden 5-point star
  const drawStar = (ctx: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) => {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();

    // Golden glow neon filling
    ctx.fillStyle = "#f59e0b"; // amber yellow
    ctx.shadowColor = "#fbbf24";
    ctx.shadowBlur = 18;
    ctx.fill();

    // Clean strokes
    ctx.shadowBlur = 0;
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = "#ffffff";
    ctx.stroke();
  };

  // Dynamic MediaPipe hands integration
  useEffect(() => {
    let active = true;
    let cameraInstance: any = null;
    let handsInstance: any = null;

    const loadMediaPipe = async () => {
      setTrackingStatus("Calibrating AR modules...");

      try {
        // Create script tags dynamically for MediaPipe
        const cameraScript = document.createElement("script");
        cameraScript.src = "https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js";
        cameraScript.crossOrigin = "anonymous";
        document.body.appendChild(cameraScript);

        const handsScript = document.createElement("script");
        handsScript.src = "https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js";
        handsScript.crossOrigin = "anonymous";
        document.body.appendChild(handsScript);

        // Wait for script loading
        await new Promise((resolve, reject) => {
          let loadedCount = 0;
          const checkLoad = () => {
            loadedCount++;
            if (loadedCount === 2) resolve(true);
          };
          cameraScript.onload = checkLoad;
          handsScript.onload = checkLoad;
          cameraScript.onerror = reject;
          handsScript.onerror = reject;
        });

        if (!active) return;

        // Verify if window objects exist
        const anyWindow = window as any;
        if (anyWindow.Hands && anyWindow.Camera && videoRef.current) {
          setTrackingStatus("Camera checking...");
          
          handsInstance = new anyWindow.Hands({
            locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
          });

          handsInstance.setOptions({
            maxNumHands: 1,
            modelComplexity: 1,
            minDetectionConfidence: 0.6,
            minTrackingConfidence: 0.6
          });

          handsInstance.onResults((results: any) => {
            if (!active || fallbackMode) return;

            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
              const landmarks = results.multiHandLandmarks[0];
              const indexTip = landmarks[8]; // Landmark 8 is the index finger tip

              if (canvasRef.current) {
                // Map coordinates
                pointerRef.current.x = indexTip.x * canvasRef.current.width;
                pointerRef.current.y = indexTip.y * canvasRef.current.height;
                pointerRef.current.active = true;
                setTrackingStatus("AR Aim Lock Enabled");
              }
            } else {
              pointerRef.current.active = false;
              setTrackingStatus("Targeting Hand...");
            }
          });

          cameraInstance = new anyWindow.Camera(videoRef.current, {
            onFrame: async () => {
              if (videoRef.current && active && !fallbackMode) {
                await handsInstance.send({ image: videoRef.current });
              }
            },
            width: 640,
            height: 480
          });

          cameraInstance.start()
            .then(() => {
              if (active) {
                setCameraActive(true);
                setTrackingStatus("AR Trials Ready");
              }
            })
            .catch((err: any) => {
              console.warn("Failed to activate webcam, defaulting to simulation", err);
              if (active) {
                setFallbackMode(true);
                setTrackingStatus("Mouse Simulator Active (Webcam Blocked)");
              }
            });
        } else {
          throw new Error("MediaPipe libraries not fully loaded.");
        }
      } catch (err) {
        console.warn("Unable to load full AR tracking modules, using Mouse Simulator", err);
        if (active) {
          setFallbackMode(true);
          setTrackingStatus("Mouse Simulator Active");
        }
      }
    };

    loadMediaPipe();

    // Game loop rendering
    let animationId: number;
    const renderLoop = () => {
      if (!active) return;
      
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      const video = videoRef.current;

      if (canvas && ctx) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // 1. Draw camera feed or custom dark vector space background
        if (video && cameraActive && !fallbackMode) {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        } else {
          // Animated grid futuristic vector space
          ctx.fillStyle = "#020617";
          ctx.fillRect(0, 0, canvas.width, canvas.height);

          // Grid lines
          ctx.strokeStyle = "rgba(147, 51, 234, 0.08)";
          ctx.lineWidth = 1;
          for (let i = 0; i < canvas.width; i += 40) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, canvas.height);
            ctx.stroke();
          }
          for (let j = 0; j < canvas.height; j += 40) {
            ctx.beginPath();
            ctx.moveTo(0, j);
            ctx.lineTo(canvas.width, j);
            ctx.stroke();
          }

          // Text notice
          ctx.fillStyle = "rgba(147, 51, 234, 0.4)";
          ctx.font = "9px monospace";
          ctx.fillText("SIMULATOR RECRUIT TRIAL SYSTEM ACTIVATED", 30, 30);
        }

        // 2. Draw Target Star
        const star = starPosRef.current;
        drawStar(ctx, star.x, star.y, 5, star.size, star.size / 2);

        // 3. Draw Pointer Crosshair
        const p = pointerRef.current;
        if (p.active) {
          // Cyan tracking cursor
          ctx.beginPath();
          ctx.arc(p.x, p.y, 10, 0, 2 * Math.PI);
          ctx.fillStyle = "rgba(6, 182, 212, 0.6)";
          ctx.shadowColor = "#06b6d4";
          ctx.shadowBlur = 10;
          ctx.fill();

          ctx.beginPath();
          ctx.arc(p.x, p.y, 18, 0, 2 * Math.PI);
          ctx.lineWidth = 2;
          ctx.strokeStyle = "#22d3ee";
          ctx.stroke();
          ctx.shadowBlur = 0;

          // Target overlap checking
          const dx = p.x - star.x;
          const dy = p.y - star.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < (star.size + 15)) {
            // Target Hit!
            playHitSound();
            scoreRef.current += 1;
            setScore(scoreRef.current);
            saveScoreToDatabase(scoreRef.current);
            spawnStar();
          }
        }
      }

      animationId = requestAnimationFrame(renderLoop);
    };

    // Initialize the star and start render loop
    spawnStar();
    renderLoop();

    return () => {
      active = false;
      cancelAnimationFrame(animationId);
      if (cameraInstance) {
        try {
          cameraInstance.stop();
        } catch (e) {}
      }
      if (handsInstance) {
        try {
          handsInstance.close();
        } catch (e) {}
      }
    };
  }, [fallbackMode, cameraActive, soundEnabled]);

  // Mouse coordinate handlers for simulator mode fallback
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (fallbackMode && canvasRef.current) {
      const rect = canvasRef.current.getBoundingClientRect();
      const relativeX = e.clientX - rect.left;
      const canvasX = (relativeX / rect.width) * canvasRef.current.width;
      
      // Since video rendering mirroring flip scaleX is applied visually to the canvas:
      // We flip pointer coordinates so they match visual hover points naturally
      pointerRef.current.x = canvasRef.current.width - canvasX;
      pointerRef.current.y = ((e.clientY - rect.top) / rect.height) * canvasRef.current.height;
      pointerRef.current.active = true;
    }
  };

  const handleMouseLeave = () => {
    if (fallbackMode) {
      pointerRef.current.active = false;
    }
  };

  return (
    <div className="w-full flex flex-col items-center">
      <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
        
        {/* Telemetry Control Panel */}
        <div id="trial-controls-panel" className="bg-gray-900/60 backdrop-blur-md rounded-2xl border border-gray-800 p-6 shadow-xl space-y-5 md:col-span-1">
          <div className="flex items-center space-x-2 border-b border-gray-800 pb-3">
            <Zap className="w-5 h-5 text-cyan-400" />
            <h3 className="font-mono text-xs font-bold tracking-widest text-white uppercase">TRIAL TELEMETRY</h3>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] text-gray-500 font-mono uppercase tracking-wider block">Trial Score</span>
            <div className="text-5xl font-black font-mono tracking-widest text-cyan-400 bg-gray-950/40 p-3 rounded-lg border border-gray-900/80 text-center select-none">
              {score < 10 ? `0${score}` : score}
            </div>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between font-mono p-2 bg-gray-950/60 rounded border border-gray-900">
              <span className="text-gray-500 text-[10px]">RECRUIT BEST:</span>
              <span className="text-purple-400 font-bold flex items-center space-x-1">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>{highScore} pts</span>
              </span>
            </div>

            <div className="flex items-center space-x-2 text-[11px] font-mono p-2 bg-purple-950/10 rounded border border-purple-900/20">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
              </span>
              <span className="text-gray-300 font-medium truncate">{trackingStatus}</span>
            </div>
          </div>

          {/* Sound & Mode Controls */}
          <div className="pt-3 border-t border-gray-800/60 space-y-3 font-mono text-[11px]">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Audio Feedback</span>
              <button
                onClick={() => setSoundEnabled(!soundEnabled)}
                className={`p-1.5 rounded cursor-pointer border ${
                  soundEnabled
                    ? "bg-cyan-950/40 border-cyan-500/30 text-cyan-400"
                    : "bg-gray-950/40 border-gray-800 text-gray-500"
                }`}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            </div>

            <div className="space-y-1.5">
              <label className="flex items-center space-x-2 text-gray-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={fallbackMode}
                  onChange={(e) => {
                    setFallbackMode(e.target.checked);
                    setTrackingStatus(e.target.checked ? "Mouse Simulator Active" : "Initializing systems...");
                  }}
                  className="rounded border-gray-800 bg-gray-950 text-cyan-500 focus:ring-0 w-3.5 h-3.5"
                />
                <span>Enable Mouse Fallback Mode</span>
              </label>
              <p className="text-[10px] text-gray-500 leading-relaxed">
                Check this box to pointer-track using your mouse cursor. Excellent for immediate performance tests without camera constraints.
              </p>
            </div>
          </div>
        </div>

        {/* Live Canvas Window */}
        <div className="md:col-span-2 flex flex-col items-center">
          <div className="w-full relative border-2 border-purple-500/30 rounded-2xl bg-slate-950 overflow-hidden shadow-2xl shadow-purple-500/5">
            {/* Mirroring class applied with visual scale-x-1 */}
            <video
              ref={videoRef}
              id="webcam-video"
              autoPlay
              playsInline
              className="hidden"
            />
            <canvas
              ref={canvasRef}
              width={640}
              height={480}
              onMouseMove={handleMouseMove}
              onMouseLeave={handleMouseLeave}
              className="w-full block transform -scale-x-100 bg-slate-950 cursor-crosshair"
            />
          </div>

          <div className="w-full mt-3 flex justify-between items-center text-[10px] text-gray-500 font-mono">
            <span className="flex items-center space-x-1 text-purple-400/80">
              <Shield className="w-3.5 h-3.5 text-purple-500" />
              <span>SECURED LOCAL FEED</span>
            </span>
            <span>GRID: 640x480 MIRRORED</span>
          </div>
        </div>

      </div>
    </div>
  );
}
