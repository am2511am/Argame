/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { Trophy, ShieldAlert, Cpu } from "lucide-react";

interface LeaderboardEntry {
  id: number;
  username: string;
  highScore: number;
}

export default function Leaderboard() {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchLeaderboard = async () => {
    try {
      const res = await fetch("/api/leaderboard");
      if (res.ok) {
        const data = await res.json();
        setEntries(data);
      }
    } catch (e) {
      console.error("Failed to load leaderboard", e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLeaderboard();
    // Poll the leaderboard every 5 seconds to keep scores fresh
    const interval = setInterval(fetchLeaderboard, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div id="leaderboard-card" className="bg-gray-900/60 backdrop-blur-md rounded-2xl border border-gray-800 p-6 shadow-xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-24 h-24 bg-purple-500/5 rounded-full blur-2xl"></div>
      
      <div className="flex items-center space-x-2 border-b border-gray-800 pb-3 mb-4">
        <Trophy className="w-5 h-5 text-amber-500 animate-pulse" />
        <h3 className="font-mono text-xs font-bold tracking-widest text-white uppercase">TOP RECRUIT LEADERBOARD</h3>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8 space-x-2">
          <Cpu className="w-4 h-4 text-cyan-400 animate-spin" />
          <span className="font-mono text-xs text-gray-500">Retrieving secure telemetry...</span>
        </div>
      ) : entries.length === 0 ? (
        <div className="text-center py-6">
          <ShieldAlert className="w-8 h-8 text-purple-500/60 mx-auto mb-2" />
          <span className="font-mono text-xs text-gray-500">No telemetry recorded yet. Be the first!</span>
        </div>
      ) : (
        <div className="space-y-2">
          {entries.map((entry, index) => {
            const rank = index + 1;
            let rankColor = "text-gray-400";
            let borderColor = "border-gray-800/40";
            let glow = "";

            if (rank === 1) {
              rankColor = "text-amber-400 font-extrabold";
              borderColor = "border-amber-500/20";
              glow = "bg-amber-950/10";
            } else if (rank === 2) {
              rankColor = "text-slate-300 font-bold";
              borderColor = "border-slate-400/15";
            } else if (rank === 3) {
              rankColor = "text-amber-600 font-medium";
            }

            return (
              <div
                key={entry.id}
                className={`flex items-center justify-between p-2.5 rounded-lg border ${borderColor} ${glow} bg-gray-950/40 hover:bg-gray-950/80 transition-colors font-mono text-xs`}
              >
                <div className="flex items-center space-x-3">
                  <span className={`w-5 text-center ${rankColor}`}>
                    {rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `#${rank}`}
                  </span>
                  <span className="text-gray-200 font-medium truncate max-w-[130px]">
                    {entry.username}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] text-gray-500">Recruit #{entry.id}</span>
                  <span className="text-cyan-400 font-bold tracking-wider">{entry.highScore} pts</span>
                </div>
              </div>
            );
          })}
        </div>
      )}
      
      <div className="mt-4 pt-3 border-t border-gray-800/60 flex justify-between items-center text-[9px] text-gray-500 font-mono">
        <span>DATA PIPELINE: LIVE</span>
        <span className="text-emerald-400 animate-ping inline-block w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
      </div>
    </div>
  );
}
