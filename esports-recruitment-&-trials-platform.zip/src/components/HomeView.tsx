/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { LogIn, Terminal, UserPlus, Cpu, AlertTriangle } from "lucide-react";
import { User } from "../types";
import Leaderboard from "./Leaderboard";

interface HomeViewProps {
  onLoginSuccess: (user: User) => void;
  onNavigateToRegister: () => void;
}

export default function HomeView({ onLoginSuccess, onNavigateToRegister }: HomeViewProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError("Please fill in all credentials.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        onLoginSuccess(data.user);
      } else {
        setError(data.error || "Access Denied: Invalid credentials.");
      }
    } catch (err) {
      setError("Unable to connect to the recruitment database. Verify your server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
      
      {/* Left side: Promo details */}
      <div className="space-y-6 lg:col-span-7">
        <div className="inline-flex items-center space-x-2 bg-purple-950/40 border border-purple-500/20 px-3 py-1 rounded-full text-[11px] text-purple-300 font-mono">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
          <span>RECRUITMENT PROTOCOL V2.4</span>
        </div>

        <h2 className="gaming-title text-3xl md:text-4xl lg:text-5xl font-black leading-tight tracking-tight text-white uppercase">
          ARE YOU THE NEXT <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">APEX LEGEND?</span>
        </h2>

        <p className="text-gray-400 text-sm md:text-base leading-relaxed">
          Welcome to Team Apex's elite full-stack recruitment portal. We don't hire based on empty words—we measure raw execution speeds and tracking accuracy in real-time. Log in below to enter the Arena and start your AR Hand-Tracking Trials.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 font-mono">
          <div className="p-4 rounded-xl bg-gray-950/40 border border-gray-800 flex items-start space-x-3">
            <Terminal className="w-5 h-5 text-cyan-400 mt-1 shrink-0" />
            <div>
              <div className="text-[10px] text-gray-500 uppercase">Trial Parameter</div>
              <div className="text-sm font-bold text-cyan-400">AR Finger-Aiming</div>
              <p className="text-[10px] text-gray-500 mt-1">Tracks index tip landmark coordinates accurately.</p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-gray-950/40 border border-gray-800 flex items-start space-x-3">
            <Cpu className="w-5 h-5 text-purple-400 mt-1 shrink-0" />
            <div>
              <div className="text-[10px] text-gray-500 uppercase">Apex Standard</div>
              <div className="text-sm font-bold text-purple-400">25+ Score Requirement</div>
              <p className="text-[10px] text-gray-500 mt-1">Hit glowing stars in quick succession to qualify.</p>
            </div>
          </div>
        </div>

        {/* Real-time scoreboard */}
        <div className="pt-2">
          <Leaderboard />
        </div>
      </div>

      {/* Right side: Login form */}
      <div id="login-card" className="bg-gray-900/60 backdrop-blur-md p-8 rounded-2xl border border-gray-800 shadow-2xl relative overflow-hidden lg:col-span-5">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-cyan-500/5 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-purple-500/5 rounded-full blur-3xl"></div>

        <div className="mb-6">
          <h3 className="gaming-title text-xl font-extrabold text-white">RECRUIT LOGIN</h3>
          <p class="text-xs text-gray-400 mt-1">Enter your credential tokens to load your player database trials.</p>
        </div>

        {error && (
          <div className="bg-red-950/80 border border-red-500/30 text-red-200 text-xs px-4 py-3 rounded-lg mb-4 font-mono flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>[ERROR] {error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 font-mono">Recruit Handle</label>
            <input
              type="text"
              required
              autoComplete="off"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-xs focus:outline-none transition-all border border-gray-800 focus:border-cyan-500 font-mono"
              placeholder="Enter username handle..."
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 font-mono">Access Key / Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-xs focus:outline-none transition-all border border-gray-800 focus:border-cyan-500 font-mono"
              placeholder="••••••••"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-purple-600 to-cyan-500 hover:from-purple-500 hover:to-cyan-400 text-white py-3 rounded-lg text-xs font-bold tracking-widest uppercase gaming-title shadow-lg shadow-cyan-500/10 cursor-pointer mt-2 flex items-center justify-center space-x-2 transition-all hover:scale-[1.02]"
          >
            {loading ? (
              <>
                <Cpu className="w-4 h-4 text-white animate-spin" />
                <span>AUTHORIZING ACCESS...</span>
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4 text-white" />
                <span>AUTHORIZE ACCESS</span>
              </>
            )}
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-800/80 text-center">
          <p className="text-xs text-gray-400">
            Unregistered recruit? 
            <button
              onClick={onNavigateToRegister}
              className="text-cyan-400 hover:text-cyan-300 font-bold transition-colors underline ml-1 cursor-pointer font-mono"
            >
              Sign Up Trial Profile &rarr;
            </button>
          </p>
        </div>
      </div>

    </div>
  );
}
