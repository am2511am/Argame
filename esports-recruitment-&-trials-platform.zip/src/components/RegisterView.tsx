/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UserPlus, ArrowLeft, CheckCircle2, AlertTriangle, Cpu } from "lucide-react";

interface RegisterViewProps {
  onBackToLogin: () => void;
}

export default function RegisterView({ onBackToLogin }: RegisterViewProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [newPlayerId, setNewPlayerId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username || !password) {
      setError("All fields are mandatory.");
      return;
    }

    if (username.trim().length < 3) {
      setError("Username must be at least 3 characters.");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setNewPlayerId(data.user.id);
        setSuccessMsg(`Registration Confirmed! Trial Profile active for Recruit.`);
      } else {
        setError(data.error || "Failed to create player trial profile.");
      }
    } catch (err) {
      setError("Could not connect to the database. Make sure Express is running.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto bg-gray-900/60 backdrop-blur-md p-8 rounded-2xl border border-gray-800 shadow-2xl relative overflow-hidden">
      <div className="absolute -top-10 -left-10 w-40 h-40 bg-purple-500/5 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-cyan-500/5 rounded-full blur-3xl"></div>

      <div className="mb-6">
        <h3 className="gaming-title text-xl font-extrabold text-white">RECRUIT TRIAL SIGN UP</h3>
        <p className="text-xs text-gray-400 mt-1">Create your database profile to start the eye-to-hand tracking trial.</p>
      </div>

      {error && (
        <div className="bg-red-950/80 border border-red-500/30 text-red-200 text-xs px-4 py-3 rounded-lg mb-4 font-mono flex items-start space-x-2">
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
          <span>[ERROR] {error}</span>
        </div>
      )}

      {successMsg ? (
        <div className="space-y-4">
          <div className="bg-emerald-950/60 border border-emerald-500/30 text-emerald-200 text-xs p-4 rounded-xl font-mono space-y-3">
            <div className="flex items-center space-x-2 text-emerald-400 font-bold">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>REGISTRATION CONFIRMED</span>
            </div>
            <p className="leading-relaxed">
              {successMsg}
            </p>
            <div className="bg-gray-950/80 p-3 rounded-lg border border-gray-800 flex justify-between items-center">
              <span className="text-gray-500 text-[10px]">RECRUIT ID:</span>
              <span className="text-cyan-400 font-bold tracking-wider">#{newPlayerId}</span>
            </div>
            <p className="text-[10px] text-emerald-400/80">
              Your profile is fully initialized. Ready for performance trials?
            </p>
          </div>

          <button
            onClick={onBackToLogin}
            className="w-full bg-gradient-to-r from-emerald-600 to-cyan-500 hover:from-emerald-500 hover:to-cyan-400 text-black py-3 rounded-lg text-xs font-bold tracking-widest uppercase gaming-title cursor-pointer flex items-center justify-center space-x-2 shadow-lg shadow-emerald-500/10 transition-transform hover:scale-[1.01]"
          >
            <span>Proceed to Login</span>
            <ArrowLeft className="w-4 h-4 text-black rotate-180" />
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 font-mono">Desired Username</label>
            <input
              type="text"
              required
              autoComplete="off"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-xs focus:outline-none transition-all border border-gray-800 focus:border-cyan-500 font-mono"
              placeholder="Choose handle..."
            />
          </div>

          <div>
            <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2 font-mono">Secret Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-xs focus:outline-none transition-all border border-gray-800 focus:border-cyan-500 font-mono"
              placeholder="Min 6 secure characters"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white py-3 rounded-lg text-xs font-bold tracking-widest uppercase gaming-title shadow-lg shadow-cyan-500/10 cursor-pointer mt-2 flex items-center justify-center space-x-2 transition-transform hover:scale-[1.01]"
          >
            {loading ? (
              <>
                <Cpu className="w-4 h-4 text-white animate-spin" />
                <span>COMMITTING TO DATABASE...</span>
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4 text-white" />
                <span>REGISTER PROFILE</span>
              </>
            )}
          </button>

          <div className="mt-6 pt-6 border-t border-gray-800/80 text-center">
            <button
              type="button"
              onClick={onBackToLogin}
              className="text-xs text-gray-400 hover:text-cyan-400 font-bold transition-colors inline-flex items-center space-x-2 font-mono cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Return to Login</span>
            </button>
          </div>
        </form>
      )}

    </div>
  );
}
