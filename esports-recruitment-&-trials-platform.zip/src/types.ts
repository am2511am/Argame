/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface User {
  id: number;
  username: string;
  highScore: number;
}

export interface GameState {
  currentScore: number;
  highScore: number;
  starX: number;
  starY: number;
  pointerX: number;
  pointerY: number;
  pointerActive: boolean;
  trackingStatus: string;
  fallbackMode: boolean;
}

export interface AuthResponse {
  success: boolean;
  error?: string;
  user?: User;
}

export interface ScoreResponse {
  success: boolean;
  newHighScore: boolean;
  highScore: number;
}
