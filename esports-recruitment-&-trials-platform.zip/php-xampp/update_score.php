<?php
// update_score.php
// Secure AJAX endpoint to update recruit high scores

header('Content-Type: application/json');
session_start();
require_once 'db_connect.php';

// Verify the player is authorized
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized recruit session.'
    ]);
    exit();
}

$userId = $_SESSION['user_id'];
$incomingScore = filter_input(INPUT_POST, 'score', FILTER_VALIDATE_INT);

if ($incomingScore === false || $incomingScore === null) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid score structure.'
    ]);
    exit();
}

try {
    // Fetch user's current high score
    $stmt = $pdo->prepare('SELECT high_score FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $currentHighScore = $stmt->fetchColumn();

    $newHighScoreAchieved = false;

    // Check if the current score is higher than the historical high score
    if ($incomingScore > $currentHighScore) {
        $updateStmt = $pdo->prepare('UPDATE users SET high_score = ? WHERE id = ?');
        $updateStmt->execute([$incomingScore, $userId]);
        
        $_SESSION['high_score'] = $incomingScore; // Update session cache
        $currentHighScore = $incomingScore;
        $newHighScoreAchieved = true;
    }

    echo json_encode([
        'status' => 'success',
        'new_high_score' => $newHighScoreAchieved,
        'high_score' => (int)$currentHighScore
    ]);
} catch (\PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database update error: ' . $e->getMessage()
    ]);
}
?>
