<?php
// register.php
// User Registration for the Esports Trials Platform
session_start();
require_once 'db_connect.php';

$success_message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        try {
            // Check if the username already exists
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM users WHERE username = ?');
            $stmt->execute([$username]);
            $exists = $stmt->fetchColumn();

            if ($exists > 0) {
                $error = 'Recruit handle already occupied. Select a different Username.';
            } else {
                // Hash the password securely
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert the new user into the database
                $stmt = $pdo->prepare('INSERT INTO users (username, password, high_score) VALUES (?, ?, 0)');
                $stmt->execute([$username, $hashed_password]);
                
                // Get the generated auto-increment user ID
                $new_player_id = $pdo->lastInsertId();
                $success_message = "Registration Confirmed! Trial Profile active for Recruit #$new_player_id.";
            }
        } catch (\PDOException $e) {
            $error = 'Database error occurred: ' . $e->getMessage();
        }
    } else {
        $error = 'All fields are mandatory.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Apex // Register Recruit Trial Profile</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0b0f19;
            background-image: 
                radial-gradient(at 0% 0%, rgba(147, 51, 234, 0.15) 0, transparent 50%), 
                radial-gradient(at 100% 100%, rgba(6, 182, 212, 0.15) 0, transparent 50%);
        }
        .gaming-title {
            font-family: 'Orbitron', sans-serif;
            text-shadow: 0 0 10px rgba(6, 182, 212, 0.6), 0 0 20px rgba(147, 51, 234, 0.3);
        }
        .cyber-border {
            box-shadow: 0 0 15px rgba(147, 51, 234, 0.2);
            border: 1px solid rgba(147, 51, 234, 0.3);
        }
        .cyber-border:focus-within {
            box-shadow: 0 0 20px rgba(6, 182, 212, 0.5);
            border-color: rgba(6, 182, 212, 0.8);
        }
        .neon-glow-btn {
            background: linear-gradient(135deg, #06b6d4 0%, #9333ea 100%);
            box-shadow: 0 0 15px rgba(147, 51, 234, 0.4);
            transition: all 0.3s ease;
        }
        .neon-glow-btn:hover {
            box-shadow: 0 0 25px rgba(147, 51, 234, 0.8), 0 0 35px rgba(6, 182, 212, 0.5);
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="min-h-screen text-gray-100 flex flex-col justify-between">

    <!-- Header -->
    <header class="w-full max-w-7xl mx-auto px-6 py-6 flex justify-between items-center border-b border-gray-800/60">
        <a href="index.php" class="flex items-center space-x-3 group">
            <div class="w-10 h-10 rounded bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/20 group-hover:scale-105 transition-transform">
                <span class="gaming-title font-black text-xl text-white">A</span>
            </div>
            <div>
                <h1 class="gaming-title text-lg font-bold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">TEAM APEX</h1>
                <p class="text-[9px] text-cyan-400/80 uppercase tracking-widest font-mono">Esports Recruitment</p>
            </div>
        </a>
        <div class="text-xs text-gray-500 font-mono">
            SYS_STATUS: <span class="text-purple-400 animate-pulse">● SECURE_SIGNUP</span>
        </div>
    </header>

    <!-- Main Registration Section -->
    <main class="flex-grow flex items-center justify-center px-4 py-12">
        <div class="w-full max-w-md bg-gray-900/80 backdrop-blur-md p-8 rounded-2xl border border-gray-800 shadow-2xl relative overflow-hidden">
            <div class="absolute -top-10 -left-10 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl"></div>
            <div class="absolute -bottom-10 -right-10 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl"></div>

            <div class="mb-6">
                <h2 class="gaming-title text-2xl font-extrabold text-white">TRIAL SIGN UP</h2>
                <p class="text-xs text-gray-400">Create your unique esports profile to start the eye-to-hand tracking trial.</p>
            </div>

            <!-- Error Notification -->
            <?php if (!empty($error)): ?>
                <div class="bg-red-950/80 border border-red-500/40 text-red-200 text-xs px-4 py-3 rounded-lg mb-4 font-mono">
                    [ERROR] <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <!-- Success Notification -->
            <?php if (!empty($success_message)): ?>
                <div class="bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 text-xs px-4 py-4 rounded-lg mb-4 space-y-3">
                    <p class="font-mono font-bold">[SUCCESS] <?php echo htmlspecialchars($success_message); ?></p>
                    <p class="text-[11px] text-emerald-300">Your profile is fully initialized. Ready for the trials?</p>
                    <a href="index.php" class="inline-block bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs px-4 py-2 rounded uppercase font-mono transition-colors">
                        Proceed to Login &rarr;
                    </a>
                </div>
            <?php endif; ?>

            <?php if (empty($success_message)): ?>
                <form method="POST" action="register.php" class="space-y-5">
                    <div>
                        <label class="block text-xs font-semibold text-gray-300 uppercase tracking-wider mb-2 font-mono">Desired Username</label>
                        <input type="text" name="username" required autocomplete="off"
                               class="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-sm focus:outline-none transition-all cyber-border font-mono"
                               placeholder="Choose recruit moniker...">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-gray-300 uppercase tracking-wider mb-2 font-mono">Secret Password</label>
                        <input type="password" name="password" required
                               class="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-sm focus:outline-none transition-all cyber-border font-mono"
                               placeholder="Min 6 secure characters">
                    </div>

                    <button type="submit" class="w-full neon-glow-btn py-3 rounded-lg text-sm font-bold tracking-widest text-white uppercase gaming-title cursor-pointer mt-2">
                        REGISTER PROFILE
                    </button>
                </form>
            <?php endif; ?>

            <div class="mt-6 pt-6 border-t border-gray-800 text-center">
                <p class="text-xs text-gray-400">
                    Already Registered? 
                    <a href="index.php" class="text-cyan-400 hover:text-cyan-300 font-bold transition-colors underline ml-1 font-mono">
                        &larr; Return to Login
                    </a>
                </p>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="w-full max-w-7xl mx-auto px-6 py-6 border-t border-gray-800/60 text-center text-xs text-gray-500 font-mono">
        &copy; <?php echo date('Y'); ?> TEAM APEX ESPORTS ENTERPRISES. ALL RIGHTS RESERVED. SECURE IP PROTOCOL ACTIVE.
    </footer>

</body>
</html>
