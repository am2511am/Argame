<?php
// game.php
// Esports AR Hand-Tracking Trials Arena
session_start();
require_once 'db_connect.php';

// Secure the page - redirect to login if session not set
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

// Fetch the latest High Score from the database to ensure it's up to date
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'];
$highScore = 0;

try {
    $stmt = $pdo->prepare('SELECT high_score FROM users WHERE id = ?');
    $stmt->execute([$userId]);
    $highScore = $stmt->fetchColumn();
    $_SESSION['high_score'] = $highScore; // update session cache
} catch (\PDOException $e) {
    // Fail gracefully with session cached high score
    $highScore = $_SESSION['high_score'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Apex // AR hand-Tracking Arena</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">
    
    <!-- MediaPipe Hands CDNs -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>

    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0b0f19;
            background-image: 
                radial-gradient(at 0% 0%, rgba(147, 51, 234, 0.12) 0, transparent 50%), 
                radial-gradient(at 100% 100%, rgba(6, 182, 212, 0.12) 0, transparent 50%);
        }
        .gaming-title {
            font-family: 'Orbitron', sans-serif;
            text-shadow: 0 0 10px rgba(6, 182, 212, 0.5);
        }
        .canvas-container {
            position: relative;
            background: #020617;
            border: 2px solid rgba(147, 51, 234, 0.4);
            box-shadow: 0 0 30px rgba(147, 51, 234, 0.15);
            border-radius: 1rem;
            overflow: hidden;
        }
        /* Hide original video, we will render it on canvas instead */
        #webcam-video {
            display: none;
            transform: scaleX(-1); /* mirror webcam */
        }
        #game-canvas {
            transform: scaleX(-1); /* mirror canvas to align with natural movement */
            width: 100%;
            max-width: 640px;
            height: 480px;
            display: block;
        }
    </style>
</head>
<body class="min-h-screen text-gray-100 flex flex-col justify-between">

    <!-- Header bar -->
    <header class="w-full max-w-7xl mx-auto px-6 py-4 flex justify-between items-center border-b border-gray-800/60">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 rounded bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg">
                <span class="gaming-title font-black text-sm text-white">A</span>
            </div>
            <div>
                <h1 class="gaming-title text-sm font-bold tracking-widest bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">TEAM APEX // TRIALS</h1>
            </div>
        </div>

        <div class="flex items-center space-x-6 font-mono text-xs">
            <div class="text-right">
                <span class="text-gray-400">RECRUIT:</span>
                <span class="text-cyan-400 font-bold"><?php echo htmlspecialchars($username); ?></span>
            </div>
            <div class="h-6 w-px bg-gray-800"></div>
            <div class="text-right">
                <span class="text-gray-400">ALL-TIME BEST:</span>
                <span id="all-time-high" class="text-purple-400 font-bold"><?php echo $highScore; ?> pts</span>
            </div>
            <div class="h-6 w-px bg-gray-800"></div>
            <a href="logout.php" class="bg-red-950/40 hover:bg-red-900/60 text-red-400 border border-red-500/30 px-3 py-1.5 rounded transition-all text-xs font-bold uppercase">
                LOGOUT
            </a>
        </div>
    </header>

    <!-- Main Game Area -->
    <main class="flex-grow flex flex-col items-center justify-center px-4 py-8">
        <div class="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <!-- Left Side Controls and instructions -->
            <div class="space-y-6 lg:col-span-1">
                <div class="p-6 rounded-2xl bg-gray-900/60 border border-gray-800 space-y-4">
                    <h2 class="gaming-title text-xl font-bold text-white border-b border-gray-800 pb-2">TRIAL CONTROLS</h2>
                    
                    <div class="space-y-2">
                        <p class="text-xs text-gray-400 font-mono">CURRENT TRIAL SCORE</p>
                        <div class="text-5xl font-extrabold tracking-widest gaming-title text-cyan-400" id="current-score">
                            00
                        </div>
                    </div>

                    <div class="pt-4 space-y-2 text-xs">
                        <div class="flex items-center space-x-2 text-green-400 font-mono">
                            <span class="w-2 h-2 rounded-full bg-green-400 animate-ping"></span>
                            <span id="tracking-status">Camera Off / Initializing...</span>
                        </div>
                        <p class="text-gray-500 font-serif leading-relaxed">
                            Place your hand in front of the camera. Tracked index tip acts as your high-precision pointer. Match the moving stars to recruit points.
                        </p>
                    </div>

                    <!-- Backup Simulator Option -->
                    <div class="pt-4 border-t border-gray-800/80 space-y-2">
                        <label class="flex items-center space-x-2 text-xs font-mono cursor-pointer">
                            <input type="checkbox" id="mouse-fallback" class="rounded border-gray-700 bg-gray-950 text-cyan-500 focus:ring-0">
                            <span>Enable Mouse Hover Mode (Fallback/Debug)</span>
                        </label>
                        <p class="text-[10px] text-gray-500 font-mono">
                            Use this if you do not have a camera or MediaPipe blocks.
                        </p>
                    </div>
                </div>

                <div class="p-6 rounded-2xl bg-gray-900/40 border border-gray-800 text-xs text-gray-400 space-y-3 font-mono">
                    <h3 class="text-purple-400 font-bold uppercase tracking-wider">Calibration Instructions</h3>
                    <ul class="list-disc pl-4 space-y-1">
                        <li>Ensure well-lit background.</li>
                        <li>Position hand 1-2 feet from camera.</li>
                        <li>Your <strong class="text-cyan-400">index finger tip</strong> is the golden crosshair tracker.</li>
                    </ul>
                </div>
            </div>

            <!-- Right Side: Canvas and video stream container -->
            <div class="lg:col-span-2 flex flex-col items-center justify-center">
                <div class="canvas-container w-full">
                    <!-- Invisible webcam stream -->
                    <video id="webcam-video" autoplay playsinline width="640" height="480"></video>
                    <!-- Game Canvas overlay -->
                    <canvas id="game-canvas" width="640" height="480"></canvas>
                </div>
                <div class="w-full flex justify-between px-2 pt-3 text-[10px] text-gray-500 font-mono">
                    <span>TRIALS PROTOCOL V2.4</span>
                    <span>RESOLUTION: 640x480 (MIRRORED)</span>
                </div>
            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="w-full max-w-7xl mx-auto px-6 py-4 border-t border-gray-800/60 text-center text-xs text-gray-500 font-mono">
        &copy; <?php echo date('Y'); ?> TEAM APEX ESPORTS. TRIAL TELEMETRY PIPELINE ONLINE.
    </footer>

    <!-- Game Script -->
    <script>
        // Game variables
        const videoElement = document.getElementById('webcam-video');
        const canvasElement = document.getElementById('game-canvas');
        const canvasCtx = canvasElement.getContext('2d');
        const currentScoreElement = document.getElementById('current-score');
        const allTimeHighElement = document.getElementById('all-time-high');
        const trackingStatus = document.getElementById('tracking-status');
        const mouseFallbackCheckbox = document.getElementById('mouse-fallback');

        let score = 0;
        let high_score = <?php echo $highScore; ?>;
        let star = { x: 320, y: 240, size: 25 }; // star position and size
        let pointer = { x: 0, y: 0, active: false }; // tracked pointer (either hand index tip or mouse)

        // Mouse hover debug mode fallback
        canvasElement.addEventListener('mousemove', (e) => {
            if (mouseFallbackCheckbox.checked) {
                const rect = canvasElement.getBoundingClientRect();
                // Since the canvas is mirrored visually using CSS (transform: scaleX(-1)),
                // we calculate coordinate appropriately
                const relativeX = e.clientX - rect.left;
                const canvasX = (relativeX / rect.width) * canvasElement.width;
                // Reverse X since the canvas layout is scaled -1
                pointer.x = canvasElement.width - canvasX;
                pointer.y = ((e.clientY - rect.top) / rect.height) * canvasElement.height;
                pointer.active = true;
            }
        });

        canvasElement.addEventListener('mouseleave', () => {
            if (mouseFallbackCheckbox.checked) {
                pointer.active = false;
            }
        });

        // Generate a new star location (avoiding absolute margins)
        function spawnStar() {
            star.x = Math.floor(Math.random() * (canvasElement.width - 100)) + 50;
            star.y = Math.floor(Math.random() * (canvasElement.height - 100)) + 50;
        }

        // Draw golden five-point star on canvas
        function drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius) {
            let rot = Math.PI / 2 * 3;
            let x = cx;
            let y = cy;
            let step = Math.PI / spikes;

            ctx.beginPath();
            ctx.moveTo(cx, cy - outerRadius);
            for (let i = 0; i < spikes; i++) {
                x = cx + Math.cos(rot) * outerRadius;
                y = cy + Math.sin(rot) * outerRadius;
                ctx.lineTo(x, y);
                rot += step;

                x = cx + Math.cos(rot) * innerRadius;
                y = cy + Math.sin(rot) * innerRadius;
                ctx.lineTo(x, y);
                rot += step;
            }
            ctx.lineTo(cx, cy - outerRadius);
            ctx.closePath();
            
            // Neon neon star styling
            ctx.fillStyle = '#f59e0b'; // amber golden
            ctx.shadowColor = '#fbbf24';
            ctx.shadowBlur = 15;
            ctx.fill();
            
            // Clean shadows
            ctx.shadowBlur = 0;
            ctx.lineWidth = 2;
            ctx.strokeStyle = '#fff';
            ctx.stroke();
        }

        // Update High Score asynchronously to update_score.php
        function saveScore(scoreToSend) {
            const formData = new FormData();
            formData.append('score', scoreToSend);

            fetch('update_score.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success' && data.new_high_score) {
                    high_score = data.high_score;
                    allTimeHighElement.textContent = high_score + ' pts';
                    // Sparkle high score visual
                    allTimeHighElement.classList.add('text-cyan-400');
                    setTimeout(() => allTimeHighElement.classList.remove('text-cyan-400'), 1000);
                }
            })
            .catch(error => console.error('Error saving high score:', error));
        }

        // Check distance for overlap collision
        function checkCollision() {
            if (!pointer.active) return;
            const dx = pointer.x - star.x;
            const dy = pointer.y - star.y;
            const distance = Math.sqrt(dx * dx + dy * dy);

            // If distance is less than sum of pointer bubble + star size
            if (distance < (star.size + 15)) {
                score++;
                currentScoreElement.textContent = score < 10 ? '0' + score : score;
                
                // Trigger rapid background save
                saveScore(score);
                
                // Spawn new star
                spawnStar();
            }
        }

        // Game loop (canvas redrawing)
        function gameLoop() {
            canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

            // 1. Draw camera feed frame directly onto canvas
            try {
                canvasCtx.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
            } catch (e) {
                // If camera is not ready, draw dark futuristic background
                canvasCtx.fillStyle = '#020617';
                canvasCtx.fillRect(0, 0, canvasElement.width, canvasElement.height);
                
                canvasCtx.fillStyle = '#334155';
                canvasCtx.font = '14px monospace';
                canvasCtx.fillText('CAMERA DISCONNECTED / PREPARING TRIAL FEED...', 40, 240);
            }

            // 2. Draw Target Star
            drawStar(canvasCtx, star.x, star.y, 5, star.size, star.size / 2);

            // 3. Draw pointer crosshairs if pointer is active
            if (pointer.active) {
                canvasCtx.beginPath();
                canvasCtx.arc(pointer.x, pointer.y, 10, 0, 2 * Math.PI);
                canvasCtx.fillStyle = 'rgba(6, 182, 212, 0.6)'; // cyan transparent finger dot
                canvasCtx.shadowColor = '#06b6d4';
                canvasCtx.shadowBlur = 10;
                canvasCtx.fill();
                
                // Draw crosshair ring
                canvasCtx.beginPath();
                canvasCtx.arc(pointer.x, pointer.y, 18, 0, 2 * Math.PI);
                canvasCtx.lineWidth = 2;
                canvasCtx.strokeStyle = '#22d3ee';
                canvasCtx.stroke();
                canvasCtx.shadowBlur = 0;
            }

            // Run collision logic continuously
            checkCollision();

            requestAnimationFrame(gameLoop);
        }

        // Start game rendering loop
        spawnStar();
        requestAnimationFrame(gameLoop);

        // --- MediaPipe Hands setup ---
        const hands = new Hands({
            locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
        });

        hands.setOptions({
            maxNumHands: 1,
            modelComplexity: 1,
            minDetectionConfidence: 0.6,
            minTrackingConfidence: 0.6
        });

        // Set up callback function to process MediaPipe tracking output
        hands.onResults((results) => {
            if (mouseFallbackCheckbox.checked) {
                // Skip camera hand detection when mouse simulation mode is checked
                return;
            }

            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                const landmarks = results.multiHandLandmarks[0];
                // MediaPipe Index finger tip is landmark #8
                const indexFingerTip = landmarks[8];
                
                // Map relative coordinates to canvas space
                pointer.x = indexFingerTip.x * canvasElement.width;
                pointer.y = indexFingerTip.y * canvasElement.height;
                pointer.active = true;

                trackingStatus.textContent = 'Tracking Core Locked';
                trackingStatus.className = 'text-cyan-400 font-mono';
            } else {
                pointer.active = false;
                trackingStatus.textContent = 'Searching for Hand...';
                trackingStatus.className = 'text-purple-400 font-mono animate-pulse';
            }
        });

        // Initialize user webcam
        const camera = new Camera(videoElement, {
            onFrame: async () => {
                await hands.send({ image: videoElement });
            },
            width: 640,
            height: 480
        });

        camera.start()
            .then(() => {
                trackingStatus.textContent = 'Ready: Position Hand';
                trackingStatus.className = 'text-cyan-400 font-mono';
            })
            .catch(err => {
                console.warn("Camera failed to start automatically. Ready for fallback.", err);
                trackingStatus.textContent = 'Camera Blocked - Mouse Mode Enabled';
                trackingStatus.className = 'text-amber-500 font-mono';
                mouseFallbackCheckbox.checked = true; // Auto-fallback to mouse simulation
            });

    </script>
</body>
</html>
