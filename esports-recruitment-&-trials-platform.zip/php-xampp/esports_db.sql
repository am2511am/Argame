-- SQL Script to set up the Esports Recruitment Database
-- Save this file and import it via phpMyAdmin or run it in your MySQL Console.

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS `esports_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `esports_db`;

-- Create users table
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `high_score` INT(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
