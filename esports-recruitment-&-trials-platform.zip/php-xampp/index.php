<?php
// index.php
// Login & Esports Recruitment Hub Page
session_start();
require_once 'db_connect.php';

$error = '';

// If already logged in, redirect to the AR trials game page
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($username) && !empty($password)) {
        try {
            // Retrieve user details from database
            $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ?');
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            // Verify password hash
            if ($user && password_verify($password, $user['password'])) {
                // Set session variables upon successful authentication
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['high_score'] = $user['high_score'];

                header("Location: game.php");
                exit();
            } else {
                $error = 'Access Denied: Invalid Username or Password.';
            }
        } catch (\PDOException $e) {
            $error = 'Database error occurred: ' . $e->getMessage();
        }
    } else {
        $error = 'Please fill in all credentials.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Apex // Esports Recruitment</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Google Fonts: Orbitron for gaming titles & Inter for body -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Orbitron:wght@500;700;900&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #0b0f19;
            background-image: 
                radial-gradient(at 0% 0%, rgba(147, 51, 234, 0.15) 0, transparent 50%), 
                radial-gradient(at 100% 100%, rgba(6, 182, 212, 0.15) 0, transparent 50%);
        }
        .gaming-title {
            font-family: 'Orbitron', sans-serif;
            text-shadow: 0 0 10px rgba(6, 182, 212, 0.6), 0 0 20px rgba(147, 51, 234, 0.3);
        }
        .cyber-border {
            box-shadow: 0 0 15px rgba(147, 51, 234, 0.2);
            border: 1px solid rgba(147, 51, 234, 0.3);
        }
        .cyber-border:focus-within {
            box-shadow: 0 0 20px rgba(6, 182, 212, 0.5);
            border-color: rgba(6, 182, 212, 0.8);
        }
        .neon-glow-btn {
            background: linear-gradient(135deg, #9333ea 0%, #06b6d4 100%);
            box-shadow: 0 0 15px rgba(6, 182, 212, 0.4);
            transition: all 0.3s ease;
        }
        .neon-glow-btn:hover {
            box-shadow: 0 0 25px rgba(6, 182, 212, 0.8), 0 0 35px rgba(147, 51, 234, 0.5);
            transform: translateY(-2px);
        }
    </style>
</head>
<body class="min-h-screen text-gray-100 flex flex-col justify-between">

    <!-- Header / Branding Bar -->
    <header class="w-full max-w-7xl mx-auto px-6 py-6 flex justify-between items-center border-b border-gray-800/60">
        <div class="flex items-center space-x-3">
            <div class="w-10 h-10 rounded bg-gradient-to-tr from-purple-600 to-cyan-500 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <span class="gaming-title font-black text-xl text-white">A</span>
            </div>
            <div>
                <h1 class="gaming-title text-lg font-bold tracking-wider bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">TEAM APEX</h1>
                <p class="text-[9px] text-cyan-400/80 uppercase tracking-widest font-mono">Esports Recruitment</p>
            </div>
        </div>
        <div class="text-xs text-gray-500 font-mono">
            SYS_STATUS: <span class="text-green-400 animate-pulse">● TRIALS_OPEN</span>
        </div>
    </header>

    <!-- Main Section -->
    <main class="flex-grow flex items-center justify-center px-4 py-12">
        <div class="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            
            <!-- Left Side: Recruiting Promo Information -->
            <div class="space-y-6">
                <div class="inline-flex items-center space-x-2 bg-purple-950/40 border border-purple-500/30 px-3 py-1 rounded-full text-xs text-purple-300 font-mono">
                    <span class="w-2 h-2 rounded-full bg-cyan-400 animate-ping"></span>
                    <span>ACTIVE TRIAL CALLOUT</span>
                </div>
                <h2 class="gaming-title text-4xl lg:text-5xl font-black leading-tight">
                    ARE YOU THE <span class="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-cyan-400">NEXT APEX LEGEND?</span>
                </h2>
                <p class="text-gray-400 leading-relaxed text-sm lg:text-base">
                    Welcome to Team Apex's elite recruitment portal. We don't hire based on words—we hire based on raw, tracked execution. Register, log in, and enter our Augmented Reality Hand-Tracking Trial to submit your precision scores. 
                </p>
                <div class="grid grid-cols-2 gap-4 pt-4 font-mono">
                    <div class="p-4 rounded-lg bg-gray-900/50 border border-gray-800">
                        <div class="text-xs text-gray-500 uppercase">Tracked Parameter</div>
                        <div class="text-lg font-bold text-cyan-400">AR Finger-Aim</div>
                    </div>
                    <div class="p-4 rounded-lg bg-gray-900/50 border border-gray-800">
                        <div class="text-xs text-gray-500 uppercase">Recruit Standard</div>
                        <div class="text-lg font-bold text-purple-400">25+ Score Target</div>
                    </div>
                </div>
            </div>

            <!-- Right Side: Sleek Login Form Card -->
            <div class="bg-gray-900/80 backdrop-blur-md p-8 rounded-2xl border border-gray-800 shadow-2xl relative overflow-hidden">
                <div class="absolute -top-10 -right-10 w-40 h-40 bg-cyan-500/10 rounded-full blur-3xl"></div>
                <div class="absolute -bottom-10 -left-10 w-40 h-40 bg-purple-500/10 rounded-full blur-3xl"></div>

                <div class="mb-6">
                    <h3 class="gaming-title text-2xl font-extrabold text-white">RECRUIT LOGIN</h3>
                    <p class="text-xs text-gray-400">Enter your credentials to access the AR Hand-Tracking Arena.</p>
                </div>

                <?php if (!empty($error)): ?>
                    <div class="bg-red-950/80 border border-red-500/40 text-red-200 text-xs px-4 py-3 rounded-lg mb-4 font-mono">
                        [ERROR] <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="index.php" class="space-y-5">
                    <div>
                        <label class="block text-xs font-semibold text-gray-300 uppercase tracking-wider mb-2 font-mono">Username</label>
                        <input type="text" name="username" required autocomplete="off"
                               class="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-sm focus:outline-none transition-all cyber-border font-mono"
                               placeholder="Enter recruit handle...">
                    </div>

                    <div>
                        <label class="block text-xs font-semibold text-gray-300 uppercase tracking-wider mb-2 font-mono">Access Key / Password</label>
                        <input type="password" name="password" required
                               class="w-full bg-gray-950 text-white rounded-lg px-4 py-3 text-sm focus:outline-none transition-all cyber-border font-mono"
                               placeholder="••••••••">
                    </div>

                    <button type="submit" class="w-full neon-glow-btn py-3 rounded-lg text-sm font-bold tracking-widest text-white uppercase gaming-title cursor-pointer mt-2">
                        AUTHORIZE ACCESS
                    </button>
                </form>

                <div class="mt-6 pt-6 border-t border-gray-800 text-center">
                    <p class="text-xs text-gray-400">
                        New Recruit? 
                        <a href="register.php" class="text-cyan-400 hover:text-cyan-300 font-bold transition-colors underline ml-1">
                            Register Trial Profile &rarr;
                        </a>
                    </p>
                </div>
            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="w-full max-w-7xl mx-auto px-6 py-6 border-t border-gray-800/60 text-center text-xs text-gray-500 font-mono">
        &copy; <?php echo date('Y'); ?> TEAM APEX ESPORTS ENTERPRISES. ALL RIGHTS RESERVED. SECURE IP PROTOCOL ACTIVE.
    </footer>

</body>
</html>
