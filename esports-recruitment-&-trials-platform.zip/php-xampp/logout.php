<?php
// logout.php
// Cleanly terminate trial session and return recruit to login landing

session_start();

// Unset all session variables
$_SESSION = [];

// If session is cookie-based, destroy the session cookie as well
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy session on server
session_destroy();

// Redirect back to login screen
header("Location: index.php");
exit();
?>
