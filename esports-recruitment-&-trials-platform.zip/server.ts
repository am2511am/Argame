/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";

interface UserDBItem {
  id: number;
  username: string;
  passwordHash: string;
  highScore: number;
}

const DB_PATH = path.join(process.cwd(), "src", "users_db.json");

// Helper to hash password using SHA-256 (mirroring standard server-side password hashing)
function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex");
}

// Helper to read database safely
function readDatabase(): UserDBItem[] {
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, "utf-8");
      return JSON.parse(data);
    }
  } catch (e) {
    console.error("Database reading error, resetting database", e);
  }
  return [];
}

// Helper to write database safely
function writeDatabase(data: UserDBItem[]): boolean {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
    return true;
  } catch (e) {
    console.error("Database writing error", e);
    return false;
  }
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body parser
  app.use(express.json());

  // API Route: Register Recruit
  app.post("/api/register", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, error: "Username and password are required." });
    }

    const trimmedUsername = username.trim();
    if (trimmedUsername.length < 3) {
      return res.status(400).json({ success: false, error: "Username must be at least 3 characters." });
    }

    const users = readDatabase();
    const exists = users.some(u => u.username.toLowerCase() === trimmedUsername.toLowerCase());

    if (exists) {
      return res.status(400).json({ success: false, error: "Recruit handle already occupied." });
    }

    const newUser: UserDBItem = {
      id: users.length > 0 ? Math.max(...users.map(u => u.id)) + 1 : 1001,
      username: trimmedUsername,
      passwordHash: hashPassword(password),
      highScore: 0
    };

    users.push(newUser);
    writeDatabase(users);

    return res.json({
      success: true,
      user: {
        id: newUser.id,
        username: newUser.username,
        highScore: newUser.highScore
      }
    });
  });

  // API Route: Login Recruit
  app.post("/api/login", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, error: "Username and password are required." });
    }

    const users = readDatabase();
    const user = users.find(u => u.username.toLowerCase() === username.trim().toLowerCase());

    if (!user || user.passwordHash !== hashPassword(password)) {
      return res.status(401).json({ success: false, error: "Access Denied: Invalid Username or Password." });
    }

    return res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        highScore: user.highScore
      }
    });
  });

  // API Route: Save / Update High Score
  app.post("/api/update_score", (req, res) => {
    const { username, score } = req.body;

    if (!username || score === undefined) {
      return res.status(400).json({ success: false, error: "Username and score are required." });
    }

    const users = readDatabase();
    const userIndex = users.findIndex(u => u.username.toLowerCase() === username.trim().toLowerCase());

    if (userIndex === -1) {
      return res.status(404).json({ success: false, error: "User profile not found." });
    }

    const currentHighScore = users[userIndex].highScore;
    let newHighScoreAchieved = false;

    if (score > currentHighScore) {
      users[userIndex].highScore = score;
      writeDatabase(users);
      newHighScoreAchieved = true;
    }

    return res.json({
      success: true,
      newHighScore: newHighScoreAchieved,
      highScore: users[userIndex].highScore
    });
  });

  // API Route: Get Leaderboard
  app.get("/api/leaderboard", (req, res) => {
    const users = readDatabase();
    const sorted = [...users]
      .sort((a, b) => b.highScore - a.highScore)
      .slice(0, 5)
      .map(u => ({ id: u.id, username: u.username, highScore: u.highScore }));

    return res.json(sorted);
  });

  // Vite middleware for dev or Static asset serving for production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[EXPRESS] Full-stack Server running on http://localhost:${PORT}`);
  });
}

startServer();
